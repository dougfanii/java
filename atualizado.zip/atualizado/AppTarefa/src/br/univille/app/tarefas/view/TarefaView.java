package br.univille.app.tarefas.view;

import java.text.SimpleDateFormat;
import java.util.List;

import br.univille.app.tarefas.modelo.Tarefa;

public class TarefaView {
	
	public void exibir(List<Tarefa> lista){
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		System.out.println("================================================================");
		System.out.println(" Tarefa                        \tPrioridade\tData\t\tFeito");
		System.out.println("================================================================");
		for(Tarefa t : lista){
			System.out.println(t.getNome()
					+"\t"+t.getPrioridade()
					+"\t\t"+format.format(t.getDate())
					+"\t"+t.isFeito());
		}
	}

}
