package br.univille.app.tarefas;

import java.util.Date;
import java.util.List;

import br.univille.app.tarefas.dao.ConnectionFactory;
import br.univille.app.tarefas.dao.TarefaDAO;
import br.univille.app.tarefas.modelo.Tarefa;
import br.univille.app.tarefas.view.TarefaView;

public class Main {

	public static void main(String[] args) {
		
		TarefaDAO dao = new TarefaDAO();
		
		Tarefa t = new Tarefa();
		/*t.setNome("Teste Inserir no banco MySql");
		t.setDate(new Date());
		t.setFeito(true);
		*/

		/*
		 * 
		 t.setId(2);
		
		dao.deletar(t);
		*
		*
		*/
//		dao.obterTodos();
//		
//		TarefaView view = new TarefaView();
//		
//		view.exibir(dao.obterTodos());
		
		t.setId(1);
		t.setFeito(true);
		dao.atualizar(t);
		
		TarefaView view = new TarefaView();
		
		view.exibir(dao.obterTodos());
		/*
		TarefaDAO dao = new TarefaDAO();
		TarefaView view = new TarefaView();
		
		Tarefa t = new Tarefa();
		t.setNome("Listar todas as tarefas       ");
		t.setDate(new Date());
		t.setFeito(true);
		
		dao.add(t);
		
		t = new Tarefa();
		t.setNome("Adicionar  tarefas          ");
		t.setDate(new Date());
		t.setFeito(true);
		
		dao.add(t);
		
		t = new Tarefa();
		t.setNome("Listar tarefas n�o realizadas");
		t.setDate(new Date());
		t.setFeito(false);
		
		dao.add(t);
		
		t = new Tarefa();
		t.setNome("Listar tarefas por prioridade");
		t.setDate(new Date());
		t.setFeito(false);
		
		dao.add(t);
		
		List<Tarefa> lista = dao.obterTarefasNaoRealizadas();
		
		view.exibir(lista);*/
		
		

	}

}
