package br.univille.app.tarefas.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {
	
	
	public Connection getConnection(){
		try{
			
			return DriverManager
					.getConnection("jdbc:mysql://localhost/banco_si" // link de conex�o
							, "root"// usuario
							, "univille"); // senha
			
		}catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}
	

}
