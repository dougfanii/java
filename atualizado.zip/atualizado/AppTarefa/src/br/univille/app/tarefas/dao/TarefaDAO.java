package br.univille.app.tarefas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.univille.app.tarefas.modelo.Tarefa;

public class TarefaDAO {
	
	private List<Tarefa> lista;
	private Connection mConn;
	
	public TarefaDAO(){
		lista = new ArrayList<Tarefa>();
		mConn = (new ConnectionFactory()).getConnection();
	}
	
	public void add(Tarefa t){
		String sql = " insert into tarefa(nome,prioridade,data,feito)"
				+"values(?,?,?,?)";
		try{
			PreparedStatement stmt = mConn.prepareStatement(sql);

			stmt.setString(1, t.getNome());
			stmt.setInt(2, t.getPrioridade());
			//java.sql.Date
			stmt.setDate(3, new java.sql.Date(t.getDate().getTime()));
			stmt.setBoolean(4, t.isFeito());
			
			stmt.execute();
			stmt.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void atualizar(Tarefa t){
		
		String sql = "UPDATE tarefa SET feito = ? WHERE id_tarefa = ?";
		try{
			PreparedStatement stmt = mConn.prepareStatement(sql);
			
			stmt.setBoolean(1, t.isFeito());
			stmt.setInt(2, t.getId());
			
			stmt.execute();
			stmt.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
		//TODO: Tarefa da tarefa da tarefa
	}
	
	public void deletar(Tarefa t){
		String sql = " delete from tarefa where id_tarefa = ?";
		try{
			PreparedStatement stmt = mConn.prepareStatement(sql);

			stmt.setInt(1, t.getId());
			
			stmt.execute();
			stmt.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
		public List<Tarefa> obterTodos(){
			List<Tarefa> lista = new ArrayList<>();
			String sql = "SELECT * FROM TAREFA";
			try {
				PreparedStatement stmt = mConn.prepareStatement(sql);
				ResultSet result = stmt.executeQuery();
				
				while(result.next()){
					Tarefa  t = new Tarefa();
					
					t.setId(result.getInt("id_tarefa"));
					t.setNome(result.getString("nome"));
					t.setDate(result.getDate("data"));
					t.setPrioridade(result.getInt("prioridade"));
					t.setFeito(result.getBoolean("feito"));
					
					lista.add(t);
				}
				
				stmt.close();
			}catch (Exception e) {
				e.printStackTrace();
			}
			
		
		return lista;
	}
	
	public List<Tarefa> obterTarefasNaoRealizadas(){
		return lista;
	}
	

}
